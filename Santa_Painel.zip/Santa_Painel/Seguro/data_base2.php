




<style>
BODY {
background-color : black;
}
</style>



<head>



<meta charset="utf-8">



</head>


<br>

<center><a href="data_base1.php"> Voltar </a></center>

<br>

<table border="2" style="width:100%">

<tr><td><font color='red' size='5'>TABELA</font></td><td><font color='red' size='5'>IP</font></td></tr>


