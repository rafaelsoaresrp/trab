

  <meta http-equiv="refresh" content=1;url="../Seguro/admin_tela.php">